import { Router, type IRouter } from "express";
import healthRouter from "./health";
import statsRouter from "./stats";
import diseaseRouter from "./disease";
import diseaseImageRouter from "./disease-image";
import qaRouter from "./qa";
import fertilizerRouter from "./fertilizer";
import consultancyRouter from "./consultancy";
import cropsRouter from "./crops";
import marketplaceRouter from "./marketplace";
import krishokCardRouter from "./krishok_card";

const router: IRouter = Router();

router.use(healthRouter);
router.use(statsRouter);
router.use(diseaseRouter);
router.use(diseaseImageRouter);
router.use(qaRouter);
router.use(fertilizerRouter);
router.use(consultancyRouter);
router.use(cropsRouter);
router.use(marketplaceRouter);
router.use(krishokCardRouter);

export default router;
