import { useGetPlatformStats } from "@workspace/api-client-react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Leaf, Map, Activity, MessageSquare, TestTube,
  Users, Sprout, ShoppingBag, CreditCard, ArrowRight,
  TrendingUp, Shield, Clock, Star,
} from "lucide-react";
import heroImage from "@assets/pngtree-concept-use-of-the-smart-farmer-system-came-to-help-an_1780547943886.jpg";

const modules = [
  { href: "/agro-map", title: "কৃষি মানচিত্র", desc: "জেলাভিত্তিক কৃষি জোন ও মাটির তথ্য দেখুন", icon: Map, gradient: "from-blue-500 to-cyan-500" },
  { href: "/disease-detector", title: "রোগ নির্ণয়", desc: "এআই দিয়ে ফসলের রোগ মুহূর্তেই সনাক্ত করুন", icon: Activity, gradient: "from-red-500 to-rose-500" },
  { href: "/qa", title: "কৃষক প্রশ্নমঞ্চ", desc: "বিশেষজ্ঞদের কাছে যেকোনো প্রশ্ন করুন", icon: MessageSquare, gradient: "from-amber-500 to-orange-500" },
  { href: "/fertilizer-guide", title: "সার নির্দেশিকা", desc: "ফসল অনুযায়ী সঠিক সারের পরিমাণ জানুন", icon: TestTube, gradient: "from-purple-500 to-violet-500" },
  { href: "/consultancy", title: "পরামর্শদাতা", desc: "অভিজ্ঞ কৃষি বিশেষজ্ঞদের সাথে কথা বলুন", icon: Users, gradient: "from-indigo-500 to-blue-500" },
  { href: "/crop-recommendation", title: "ফসল সুপারিশ", desc: "মাটি ও মৌসুম বিশ্লেষণ করে সেরা ফসল বাছুন", icon: Sprout, gradient: "from-emerald-500 to-green-500" },
  { href: "/marketplace", title: "কৃষি বাজার", desc: "সরাসরি কৃষকের কাছ থেকে পণ্য কিনুন বা বিক্রি করুন", icon: ShoppingBag, gradient: "from-orange-500 to-amber-500" },
  { href: "/krishok-card", title: "কৃষক কার্ড", desc: "কৃষক পরিচয় কার্ড নিবন্ধন ও যাচাই করুন", icon: CreditCard, gradient: "from-teal-500 to-cyan-500" },
];

const features = [
  { icon: TrendingUp, title: "উৎপাদন বৃদ্ধি", desc: "আধুনিক প্রযুক্তি ব্যবহার করে ফসলের উৎপাদন গড়ে ৩০% বাড়ান" },
  { icon: Shield, title: "রোগ সুরক্ষা", desc: "সময়মতো রোগ সনাক্ত করে ফসল ক্ষতি থেকে রক্ষা করুন" },
  { icon: Clock, title: "দ্রুত সেবা", desc: "যেকোনো সমস্যায় মুহূর্তেই বিশেষজ্ঞ পরামর্শ পান" },
  { icon: Star, title: "বিশেষজ্ঞ নেটওয়ার্ক", desc: "সারাদেশের অভিজ্ঞ কৃষিবিদদের সাথে সরাসরি যুক্ত হন" },
];

const statItems = [
  { key: "totalFarmers" as const, label: "নিবন্ধিত কৃষক", suffix: "+" },
  { key: "totalProducts" as const, label: "কৃষি পণ্য", suffix: "" },
  { key: "totalConsultants" as const, label: "বিশেষজ্ঞ", suffix: "+" },
  { key: "totalDistricts" as const, label: "জেলা কভারেজ", suffix: "টি" },
];

export default function Home() {
  const { data: stats, isLoading } = useGetPlatformStats();

  return (
    <div className="flex flex-col">

      {/* ─── Hero ─── */}
      <section className="relative min-h-[92vh] flex items-center overflow-hidden">
        {/* background image */}
        <div className="absolute inset-0">
          <img
            src={heroImage}
            alt="Bangladesh agriculture"
            className="w-full h-full object-cover object-center"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/50 to-black/20" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
        </div>

        {/* content – left aligned */}
        <div className="container relative z-10 mx-auto px-6 lg:px-12 py-24">
          <div className="max-w-2xl">
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, ease: "easeOut" }}
            >
              <span className="inline-flex items-center gap-2 bg-primary/90 text-white text-sm font-semibold px-4 py-1.5 rounded-full mb-8 backdrop-blur-sm">
                <Leaf className="w-4 h-4" />
                বাংলাদেশের #১ ডিজিটাল কৃষি প্ল্যাটফর্ম
              </span>

              <h1 className="text-5xl md:text-6xl lg:text-7xl font-extrabold text-white leading-tight mb-6 tracking-tight">
                স্মার্ট কৃষি,<br />
                <span className="text-primary">সমৃদ্ধ বাংলাদেশ</span>
              </h1>

              <p className="text-lg md:text-xl text-white/80 leading-relaxed mb-10 max-w-xl">
                আধুনিক প্রযুক্তি, বিশেষজ্ঞ পরামর্শ এবং সঠিক তথ্যের সমন্বয়ে দেশের ১৬ মিলিয়ন কৃষক পরিবারের ক্ষমতায়ন।
              </p>

              <div className="flex flex-wrap gap-4">
                <Button size="lg" className="h-13 px-8 text-base font-semibold shadow-lg shadow-primary/30 hover:shadow-primary/50 transition-shadow" asChild>
                  <Link href="/disease-detector">
                    রোগ নির্ণয় করুন
                    <ArrowRight className="ml-2 w-5 h-5" />
                  </Link>
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="h-13 px-8 text-base font-semibold border-white/40 text-white bg-white/10 hover:bg-white/20 hover:text-white hover:border-white/60 backdrop-blur-sm"
                  asChild
                >
                  <Link href="/krishok-card">কৃষক নিবন্ধন</Link>
                </Button>
              </div>
            </motion.div>

            {/* inline stats */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.35, ease: "easeOut" }}
              className="mt-16 grid grid-cols-2 sm:grid-cols-4 gap-px bg-white/10 rounded-2xl overflow-hidden backdrop-blur-sm border border-white/10"
            >
              {statItems.map((s) => (
                <div key={s.key} className="bg-black/30 px-4 py-5 text-center">
                  <p className="text-2xl md:text-3xl font-bold text-white">
                    {isLoading ? "—" : (
                      s.key === "totalFarmers"
                        ? "২,৪২০"
                        : s.key === "totalDistricts"
                        ? "৬৪"
                        : (stats?.[s.key] ?? 0).toLocaleString("bn-BD")
                    )}{s.suffix}
                  </p>
                  <p className="text-xs text-white/60 mt-1 font-medium tracking-wide uppercase">{s.label}</p>
                </div>
              ))}
            </motion.div>
          </div>
        </div>

        {/* bottom fade */}
        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent" />
      </section>

      {/* ─── Features strip ─── */}
      <section className="py-16 bg-background border-b">
        <div className="container mx-auto px-6">
          <motion.div
            initial="hidden"
            whileInView="show"
            viewport={{ once: true }}
            variants={{ hidden: {}, show: { transition: { staggerChildren: 0.1 } } }}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
          >
            {features.map((f) => (
              <motion.div
                key={f.title}
                variants={{ hidden: { opacity: 0, y: 20 }, show: { opacity: 1, y: 0 } }}
                className="flex gap-4 items-start p-5 rounded-xl bg-muted/40 hover:bg-muted/70 transition-colors"
              >
                <div className="shrink-0 w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <f.icon className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">{f.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ─── Modules grid ─── */}
      <section className="py-20 md:py-28">
        <div className="container mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <span className="text-sm font-semibold text-primary uppercase tracking-widest">আমাদের সেবাসমূহ</span>
            <h2 className="text-3xl md:text-5xl font-bold mt-3 mb-4">ডিজিটাল কৃষির সম্পূর্ণ সমাধান</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              বীজ বপন থেকে বাজারজাতকরণ — কৃষির প্রতিটি ধাপে এগ্রোবাংলা আপনার পাশে
            </p>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-60px" }}
            variants={{ hidden: {}, show: { transition: { staggerChildren: 0.07 } } }}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5"
          >
            {modules.map((mod) => (
              <motion.div
                key={mod.href}
                variants={{ hidden: { opacity: 0, y: 24 }, show: { opacity: 1, y: 0 } }}
              >
                <Link href={mod.href} className="group block h-full">
                  <Card className="h-full border-2 border-transparent hover:border-primary/20 hover:shadow-xl hover:-translate-y-1.5 transition-all duration-300 overflow-hidden">
                    <CardContent className="p-0">
                      {/* top gradient bar */}
                      <div className={`h-1.5 w-full bg-gradient-to-r ${mod.gradient}`} />
                      <div className="p-6">
                        {/* icon */}
                        <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${mod.gradient} flex items-center justify-center mb-5 shadow-md group-hover:scale-110 transition-transform duration-300`}>
                          <mod.icon className="w-7 h-7 text-white" />
                        </div>
                        <h3 className="text-lg font-bold mb-2 group-hover:text-primary transition-colors">{mod.title}</h3>
                        <p className="text-sm text-muted-foreground leading-relaxed mb-4">{mod.desc}</p>
                        <div className="flex items-center text-sm font-semibold text-primary opacity-0 group-hover:opacity-100 transition-opacity">
                          এখনই দেখুন <ArrowRight className="ml-1.5 w-4 h-4" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ─── CTA ─── */}
      <section className="relative py-24 overflow-hidden bg-primary">
        {/* decorative circles */}
        <div className="absolute -top-20 -right-20 w-96 h-96 rounded-full bg-white/5" />
        <div className="absolute -bottom-16 -left-16 w-72 h-72 rounded-full bg-white/5" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-white/[0.03]" />

        <div className="container relative z-10 mx-auto px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl md:text-5xl font-bold text-white mb-5">
              আজই শুরু করুন স্মার্ট কৃষি
            </h2>
            <p className="text-white/75 text-lg md:text-xl max-w-xl mx-auto mb-10">
              বিনামূল্যে নিবন্ধন করুন এবং বাংলাদেশের লক্ষাধিক কৃষকের সাথে যুক্ত হন।
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Button
                size="lg"
                className="h-13 px-10 text-base font-semibold bg-white text-primary hover:bg-white/90 shadow-xl"
                asChild
              >
                <Link href="/krishok-card">কৃষক কার্ডের জন্য আবেদন করুন</Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="h-13 px-10 text-base font-semibold border-white/30 text-white bg-transparent hover:bg-white/10 hover:text-white hover:border-white/50"
                asChild
              >
                <Link href="/consultancy">বিশেষজ্ঞের সাথে কথা বলুন</Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
