import { useState, useEffect, useRef } from "react";
import { useGetProducts, useCreateProduct, useDeleteProduct, useGetMarketplaceStats, getGetProductsQueryKey, getGetMarketplaceStatsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import {
  ShoppingBag, Plus, Phone, MapPin, Leaf, Trash2, Search, Package,
  ShoppingCart, TrendingUp, TrendingDown, Minus, X, CheckCircle,
  Zap, CreditCard,
} from "lucide-react";
import { toast } from "sonner";

const CATEGORIES = ["ধান", "গম", "সবজি", "ফল", "মসলা", "ডাল", "তেলবীজ", "সার", "বীজ", "সরঞ্জাম"];
const UNITS = ["কেজি", "মণ", "টন", "পিস", "লিটার", "বস্তা"];
const DISTRICTS_BN = ["ঢাকা", "চট্টগ্রাম", "রাজশাহী", "খুলনা", "বরিশাল", "সিলেট", "রংপুর", "ময়মনসিংহ"];

type Product = {
  id: number; name: string; nameBn: string; category: string;
  price: number; unit: string; quantity: number; district: string;
  sellerName: string; sellerPhone: string; description?: string | null;
  imageUrl?: string | null; isOrganic: boolean; createdAt: string;
};

type CartItem = { product: Product & { livePrice: number }; qty: number };
type PriceMap = Record<number, { price: number; trend: "up" | "down" | "same" }>;

function toBn(n: number) {
  return n.toFixed(0).replace(/\d/g, d => "০১২৩৪৫৬৭৮৯"[+d]);
}

export default function Marketplace() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState<string | undefined>(undefined);
  const [addOpen, setAddOpen] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);
  const [buyProduct, setBuyProduct] = useState<(Product & { livePrice: number }) | null>(null);
  const [buyQty, setBuyQty] = useState(1);
  const [buyOrdered, setBuyOrdered] = useState(false);
  const [cart, setCart] = useState<Record<number, CartItem>>({});
  const [livePrices, setLivePrices] = useState<PriceMap>({});
  const [form, setForm] = useState({
    name: "", nameBn: "", category: "ধান", price: "", unit: "কেজি",
    quantity: "", district: "ঢাকা", sellerName: "", sellerPhone: "",
    description: "", imageUrl: "", isOrganic: false,
  });

  const queryClient = useQueryClient();
  const { data: products, isLoading } = useGetProducts(
    { category, search: search || undefined },
    { query: { queryKey: getGetProductsQueryKey({ category, search: search || undefined }) } }
  );
  const { data: stats } = useGetMarketplaceStats({ query: { queryKey: getGetMarketplaceStatsQueryKey() } });
  const { mutate: createProduct, isPending: creating } = useCreateProduct({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetProductsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetMarketplaceStatsQueryKey() });
        setAddOpen(false);
        toast.success("পণ্য তালিকাভুক্ত হয়েছে!");
      },
      onError: () => toast.error("পণ্য যোগ করতে ব্যর্থ হয়েছে।"),
    },
  });
  const { mutate: deleteProduct } = useDeleteProduct({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetProductsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetMarketplaceStatsQueryKey() });
        toast.success("পণ্য মুছে ফেলা হয়েছে।");
      },
    },
  });

  // ── Real-time price simulation ──
  const productsRef = useRef<Product[]>([]);
  useEffect(() => {
    if (products) productsRef.current = products as Product[];
  }, [products]);

  useEffect(() => {
    if (!products?.length) return;
    // initialise live prices
    setLivePrices(prev => {
      const next = { ...prev };
      for (const p of products as Product[]) {
        if (!next[p.id]) next[p.id] = { price: p.price, trend: "same" };
      }
      return next;
    });

    const interval = setInterval(() => {
      setLivePrices(prev => {
        const next = { ...prev };
        // randomly update ~40% of products each tick
        for (const p of productsRef.current) {
          if (Math.random() > 0.6) {
            const delta = (Math.random() * 0.06 - 0.03); // ±3%
            const newPrice = Math.max(1, Math.round((prev[p.id]?.price ?? p.price) * (1 + delta)));
            const trend = newPrice > (prev[p.id]?.price ?? p.price) ? "up" : newPrice < (prev[p.id]?.price ?? p.price) ? "down" : "same";
            next[p.id] = { price: newPrice, trend };
          } else if (prev[p.id]) {
            next[p.id] = { ...prev[p.id], trend: "same" };
          }
        }
        return next;
      });
    }, 8000);

    return () => clearInterval(interval);
  }, [products?.length]);

  const getLiveProduct = (p: Product) => ({
    ...p,
    livePrice: livePrices[p.id]?.price ?? p.price,
  });

  // ── Cart helpers ──
  const cartCount = Object.values(cart).reduce((s, i) => s + i.qty, 0);
  const cartTotal = Object.values(cart).reduce((s, i) => s + i.product.livePrice * i.qty, 0);

  const addToCart = (p: Product & { livePrice: number }) => {
    setCart(prev => {
      const existing = prev[p.id];
      return { ...prev, [p.id]: { product: p, qty: (existing?.qty ?? 0) + 1 } };
    });
    toast.success(`${p.nameBn} কার্টে যোগ হয়েছে`);
  };

  const updateCartQty = (id: number, delta: number) => {
    setCart(prev => {
      const item = prev[id];
      if (!item) return prev;
      const newQty = item.qty + delta;
      if (newQty <= 0) {
        const next = { ...prev };
        delete next[id];
        return next;
      }
      return { ...prev, [id]: { ...item, qty: newQty } };
    });
  };

  const clearCart = () => setCart({});

  // ── Submit product ──
  const handleSubmit = () => {
    if (!form.name || !form.nameBn || !form.price || !form.quantity || !form.sellerName || !form.sellerPhone) {
      toast.error("সকল আবশ্যিক ক্ষেত্র পূরণ করুন।");
      return;
    }
    createProduct({
      data: { ...form, price: Number(form.price), quantity: Number(form.quantity), description: form.description || null, imageUrl: form.imageUrl || null },
    });
  };

  // ── Buy now ──
  const handleBuyNow = (p: Product & { livePrice: number }) => {
    setBuyProduct(p);
    setBuyQty(1);
    setBuyOrdered(false);
  };

  const confirmOrder = () => {
    setBuyOrdered(true);
    toast.success("অর্ডার সম্পন্ন হয়েছে! বিক্রেতা শীঘ্রই যোগাযোগ করবেন।");
  };

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="container mx-auto px-4 py-8">

      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold mb-1">কৃষি বাজার</h1>
          <div className="flex items-center gap-2">
            <p className="text-muted-foreground text-sm">সরাসরি কৃষকের কাছ থেকে কিনুন, ন্যায্য মূল্যে বিক্রি করুন</p>
            <span className="flex items-center gap-1 text-xs bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400 px-2 py-0.5 rounded-full font-medium">
              <Zap className="w-3 h-3" /> লাইভ মূল্য
            </span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {/* Cart button */}
          <Sheet open={cartOpen} onOpenChange={setCartOpen}>
            <SheetTrigger asChild>
              <Button variant="outline" className="relative gap-2">
                <ShoppingCart className="w-4 h-4" />
                কার্ট
                {cartCount > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-primary text-primary-foreground text-[10px] font-bold flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </Button>
            </SheetTrigger>
            <SheetContent className="w-full sm:max-w-md flex flex-col">
              <SheetHeader>
                <SheetTitle className="flex items-center gap-2">
                  <ShoppingCart className="w-5 h-5" /> আমার কার্ট
                  {cartCount > 0 && <Badge>{cartCount}টি পণ্য</Badge>}
                </SheetTitle>
              </SheetHeader>

              {cartCount === 0 ? (
                <div className="flex-1 flex flex-col items-center justify-center gap-3 text-muted-foreground">
                  <ShoppingBag className="w-16 h-16 opacity-20" />
                  <p>কার্ট খালি আছে</p>
                </div>
              ) : (
                <>
                  <div className="flex-1 overflow-y-auto space-y-3 py-4">
                    {Object.values(cart).map(({ product: p, qty }) => (
                      <div key={p.id} className="flex items-center gap-3 bg-muted/30 rounded-lg p-3">
                        <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center shrink-0">
                          <Leaf className="w-5 h-5 text-primary" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-sm truncate">{p.nameBn}</p>
                          <p className="text-xs text-muted-foreground">৳{p.livePrice}/{p.unit}</p>
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <Button size="icon" variant="outline" className="h-7 w-7" onClick={() => updateCartQty(p.id, -1)}>
                            <Minus className="w-3 h-3" />
                          </Button>
                          <span className="w-6 text-center text-sm font-semibold">{qty}</span>
                          <Button size="icon" variant="outline" className="h-7 w-7" onClick={() => updateCartQty(p.id, 1)}>
                            <Plus className="w-3 h-3" />
                          </Button>
                        </div>
                        <div className="text-right shrink-0">
                          <p className="text-sm font-bold text-primary">৳{(p.livePrice * qty).toLocaleString()}</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="border-t pt-4 space-y-3">
                    <div className="flex justify-between text-sm text-muted-foreground">
                      <span>মোট পণ্য</span><span>{cartCount}টি</span>
                    </div>
                    <div className="flex justify-between font-bold text-lg">
                      <span>মোট মূল্য</span>
                      <span className="text-primary">৳{cartTotal.toLocaleString()}</span>
                    </div>
                    <Button className="w-full gap-2 h-11 text-base font-semibold" onClick={() => { setCartOpen(false); toast.success("অর্ডার সম্পন্ন! বিক্রেতারা শীঘ্রই যোগাযোগ করবেন।"); clearCart(); }}>
                      <CreditCard className="w-4 h-4" /> অর্ডার করুন
                    </Button>
                    <Button variant="ghost" className="w-full text-muted-foreground" onClick={clearCart}>
                      <X className="w-3.5 h-3.5 mr-1.5" /> কার্ট খালি করুন
                    </Button>
                  </div>
                </>
              )}
            </SheetContent>
          </Sheet>

          {/* Add product */}
          <Dialog open={addOpen} onOpenChange={setAddOpen}>
            <DialogTrigger asChild>
              <Button className="flex items-center gap-2"><Plus className="w-4 h-4" />পণ্য যোগ করুন</Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader><DialogTitle>নতুন পণ্য তালিকাভুক্ত করুন</DialogTitle></DialogHeader>
              <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-1">
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1"><Label>পণ্যের নাম (বাংলা)</Label><Input value={form.nameBn} onChange={e => setForm(p => ({ ...p, nameBn: e.target.value }))} placeholder="যেমন: বোরো ধান" /></div>
                  <div className="space-y-1"><Label>Product Name (English)</Label><Input value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} placeholder="e.g. Boro Rice" /></div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1"><Label>বিভাগ</Label>
                    <Select value={form.category} onValueChange={v => setForm(p => ({ ...p, category: v }))}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>{CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1"><Label>জেলা</Label>
                    <Select value={form.district} onValueChange={v => setForm(p => ({ ...p, district: v }))}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>{DISTRICTS_BN.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <div className="space-y-1"><Label>মূল্য (৳)</Label><Input type="number" value={form.price} onChange={e => setForm(p => ({ ...p, price: e.target.value }))} placeholder="0" /></div>
                  <div className="space-y-1"><Label>একক</Label>
                    <Select value={form.unit} onValueChange={v => setForm(p => ({ ...p, unit: v }))}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>{UNITS.map(u => <SelectItem key={u} value={u}>{u}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1"><Label>পরিমাণ</Label><Input type="number" value={form.quantity} onChange={e => setForm(p => ({ ...p, quantity: e.target.value }))} placeholder="0" /></div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1"><Label>বিক্রেতার নাম</Label><Input value={form.sellerName} onChange={e => setForm(p => ({ ...p, sellerName: e.target.value }))} placeholder="নাম" /></div>
                  <div className="space-y-1"><Label>মোবাইল</Label><Input value={form.sellerPhone} onChange={e => setForm(p => ({ ...p, sellerPhone: e.target.value }))} placeholder="01XXXXXXXXX" /></div>
                </div>
                <div className="space-y-1"><Label>বিবরণ (ঐচ্ছিক)</Label><Textarea value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} rows={2} placeholder="পণ্য সম্পর্কে বিস্তারিত..." /></div>
                <div className="flex items-center gap-2">
                  <Switch id="organic" checked={form.isOrganic} onCheckedChange={v => setForm(p => ({ ...p, isOrganic: v }))} />
                  <Label htmlFor="organic">জৈব পণ্য (Organic)</Label>
                </div>
                <Button className="w-full" disabled={creating} onClick={handleSubmit}>
                  {creating ? "যোগ হচ্ছে..." : "পণ্য তালিকাভুক্ত করুন"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Stats */}
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: "মোট পণ্য", value: stats.totalProducts },
            { label: "বিক্রেতা", value: stats.totalSellers },
            { label: "জেলা", value: stats.totalDistricts },
            { label: "গড় মূল্য (৳)", value: stats.avgPrice.toFixed(0) },
          ].map(s => (
            <Card key={s.label}>
              <CardContent className="p-4 text-center">
                <p className="text-2xl font-bold text-primary">{s.value}</p>
                <p className="text-sm text-muted-foreground">{s.label}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Search & Filter */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input className="pl-9" placeholder="পণ্য খুঁজুন..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <Select value={category || "all"} onValueChange={v => setCategory(v === "all" ? undefined : v)}>
          <SelectTrigger className="w-full sm:w-44"><SelectValue placeholder="সকল বিভাগ" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">সকল বিভাগ</SelectItem>
            {CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      {/* Products grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-72" />)}
        </div>
      ) : !products?.length ? (
        <Card className="p-12 text-center">
          <Package className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground">কোনো পণ্য পাওয়া যায়নি</p>
        </Card>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {(products as Product[]).map((product, i) => {
            const lp = getLiveProduct(product);
            const trend = livePrices[product.id]?.trend ?? "same";
            const inCart = cart[product.id]?.qty ?? 0;

            return (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: Math.min(i * 0.04, 0.3) }}
              >
                <Card className="h-full hover:border-primary/40 hover:shadow-md transition-all group flex flex-col">
                  <CardContent className="p-4 flex flex-col h-full">
                    {/* Top: badges + delete */}
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-1.5 mb-1.5 flex-wrap">
                          <Badge variant="secondary" className="text-xs">{product.category}</Badge>
                          {product.isOrganic && (
                            <Badge className="text-xs bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400">
                              <Leaf className="w-2.5 h-2.5 mr-1" />জৈব
                            </Badge>
                          )}
                        </div>
                        <h3 className="font-semibold leading-tight">{product.nameBn}</h3>
                        <p className="text-xs text-muted-foreground">{product.name}</p>
                      </div>
                      <Button
                        variant="ghost" size="icon"
                        className="opacity-0 group-hover:opacity-100 transition-opacity h-7 w-7 text-destructive hover:text-destructive shrink-0"
                        onClick={() => deleteProduct({ id: product.id })}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>

                    {product.description && (
                      <p className="text-xs text-muted-foreground mb-3 line-clamp-2">{product.description}</p>
                    )}

                    <div className="mt-auto space-y-3">
                      {/* Live price */}
                      <div className="flex items-end justify-between">
                        <div>
                          <AnimatePresence mode="wait">
                            <motion.p
                              key={lp.livePrice}
                              initial={{ y: trend === "up" ? -8 : trend === "down" ? 8 : 0, opacity: 0 }}
                              animate={{ y: 0, opacity: 1 }}
                              transition={{ duration: 0.3 }}
                              className={`text-2xl font-bold ${
                                trend === "up" ? "text-green-600 dark:text-green-400"
                                : trend === "down" ? "text-red-500"
                                : "text-primary"
                              }`}
                            >
                              ৳{toBn(lp.livePrice)}
                            </motion.p>
                          </AnimatePresence>
                          <p className="text-xs text-muted-foreground">প্রতি {product.unit}</p>
                        </div>
                        <div className="text-right">
                          {trend !== "same" && (
                            <span className={`flex items-center gap-0.5 text-xs font-semibold ${trend === "up" ? "text-green-600 dark:text-green-400" : "text-red-500"}`}>
                              {trend === "up" ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
                              {trend === "up" ? "বাড়ছে" : "কমছে"}
                            </span>
                          )}
                          <p className="text-xs text-muted-foreground">{toBn(product.quantity)} {product.unit}</p>
                        </div>
                      </div>

                      {/* Seller */}
                      <div className="border-t pt-2 space-y-1">
                        <p className="text-sm font-medium">{product.sellerName}</p>
                        <div className="flex items-center gap-3 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{product.district}</span>
                          <span className="flex items-center gap-1"><Phone className="w-3 h-3" />{product.sellerPhone}</span>
                        </div>
                      </div>

                      {/* Buttons */}
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          className="flex-1 gap-1.5 text-xs"
                          onClick={() => addToCart(lp)}
                        >
                          {inCart > 0
                            ? <><ShoppingCart className="w-3.5 h-3.5" />কার্টে ({inCart})</>
                            : <><ShoppingCart className="w-3.5 h-3.5" />কার্টে যোগ</>
                          }
                        </Button>
                        <Button
                          size="sm"
                          className="flex-1 gap-1.5 text-xs"
                          onClick={() => handleBuyNow(lp)}
                        >
                          <Zap className="w-3.5 h-3.5" />এখনই কিনুন
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* ── Buy Now Dialog ── */}
      <Dialog open={!!buyProduct} onOpenChange={v => { if (!v) { setBuyProduct(null); setBuyOrdered(false); } }}>
        <DialogContent className="sm:max-w-sm">
          {buyProduct && !buyOrdered && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Zap className="w-5 h-5 text-primary" /> এখনই কিনুন
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="bg-muted/40 rounded-lg p-3 space-y-1">
                  <div className="flex justify-between">
                    <span className="font-semibold">{buyProduct.nameBn}</span>
                    <Badge variant="secondary">{buyProduct.category}</Badge>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <MapPin className="w-3.5 h-3.5" />{buyProduct.district}
                    <span className="mx-1">·</span>
                    <Phone className="w-3.5 h-3.5" />{buyProduct.sellerPhone}
                  </div>
                  <p className="text-sm">{buyProduct.sellerName}</p>
                </div>

                <div className="space-y-2">
                  <Label>পরিমাণ ({buyProduct.unit})</Label>
                  <div className="flex items-center gap-3">
                    <Button size="icon" variant="outline" onClick={() => setBuyQty(q => Math.max(1, q - 1))}>
                      <Minus className="w-4 h-4" />
                    </Button>
                    <span className="w-10 text-center font-bold text-lg">{buyQty}</span>
                    <Button size="icon" variant="outline" onClick={() => setBuyQty(q => Math.min(buyProduct.quantity, q + 1))}>
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                <Separator />

                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">মোট মূল্য</span>
                  <span className="text-2xl font-bold text-primary">৳{(buyProduct.livePrice * buyQty).toLocaleString()}</span>
                </div>

                <div className="bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-md px-3 py-2 text-xs text-amber-800 dark:text-amber-300">
                  📞 অর্ডার নিশ্চিত হলে বিক্রেতা <strong>{buyProduct.sellerPhone}</strong> থেকে যোগাযোগ করবেন।
                </div>

                <Button className="w-full h-11 text-base font-semibold gap-2" onClick={confirmOrder}>
                  <CreditCard className="w-4 h-4" /> অর্ডার নিশ্চিত করুন
                </Button>
              </div>
            </>
          )}

          {buyOrdered && (
            <div className="py-8 text-center space-y-4">
              <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", bounce: 0.4 }}>
                <CheckCircle className="w-16 h-16 text-green-500 mx-auto" />
              </motion.div>
              <div>
                <h3 className="text-xl font-bold mb-1">অর্ডার সম্পন্ন!</h3>
                <p className="text-muted-foreground text-sm">
                  {buyProduct?.sellerName} শীঘ্রই <strong>{buyProduct?.sellerPhone}</strong> থেকে আপনার সাথে যোগাযোগ করবেন।
                </p>
              </div>
              <Button className="w-full" onClick={() => { setBuyProduct(null); setBuyOrdered(false); }}>
                ঠিক আছে
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </motion.div>
  );
}
