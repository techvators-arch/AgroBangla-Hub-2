import { Link, useLocation } from "wouter";
import { useTheme } from "@/components/theme-provider";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from "@/components/ui/dialog";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger, DropdownMenuLabel,
} from "@/components/ui/dropdown-menu";
import {
  Moon, Sun, Menu, Leaf, Map, Activity, MessageSquare, TestTube,
  Users, Sprout, ShoppingBag, CreditCard, Bell,
  LogIn, LogOut, Settings, ChevronDown, CheckCheck, Loader2, AlertCircle,
} from "lucide-react";
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from "@/components/ui/sheet";
import { useState } from "react";

const links = [
  { href: "/", label: "হোম", icon: Leaf },
  { href: "/agro-map", label: "মানচিত্র", icon: Map },
  { href: "/disease-detector", label: "রোগ নির্ণয়", icon: Activity },
  { href: "/qa", label: "কৃষক প্রশ্ন", icon: MessageSquare },
  { href: "/fertilizer-guide", label: "সার নির্দেশিকা", icon: TestTube },
  { href: "/consultancy", label: "পরামর্শদাতা", icon: Users },
  { href: "/crop-recommendation", label: "ফসল সুপারিশ", icon: Sprout },
  { href: "/marketplace", label: "বাজার", icon: ShoppingBag },
  { href: "/krishok-card", label: "কৃষক কার্ড", icon: CreditCard },
];

const SAMPLE_NOTIFICATIONS = [
  { id: 1, icon: Activity, color: "text-red-500", title: "রোগ সতর্কতা", body: "ধান ব্লাস্ট রোগের প্রাদুর্ভাব ময়মনসিংহে বাড়ছে", time: "৫ মিনিট আগে", read: false },
  { id: 2, icon: Sprout, color: "text-green-500", title: "ফসল পরামর্শ", body: "এখন বোরো ধান রোপণের উপযুক্ত সময়", time: "২ ঘণ্টা আগে", read: false },
  { id: 3, icon: MessageSquare, color: "text-blue-500", title: "নতুন উত্তর", body: "আপনার প্রশ্নে বিশেষজ্ঞ উত্তর দিয়েছেন", time: "গতকাল", read: false },
  { id: 4, icon: ShoppingBag, color: "text-purple-500", title: "বাজারদর আপডেট", body: "ধানের বাজার মূল্য বৃদ্ধি পেয়েছে ৳৫/কেজি", time: "২ দিন আগে", read: true },
];

type KrishokUser = {
  name: string;
  cardNumber: string;
  nidNumber: string;
  district: string;
  upazila?: string | null;
  status: string;
};

export function Navbar() {
  const { theme, setTheme } = useTheme();
  const [location] = useLocation();
  const [open, setOpen] = useState(false);
  const [user, setUser] = useState<KrishokUser | null>(null);
  const [notifications, setNotifications] = useState(SAMPLE_NOTIFICATIONS);

  // Login dialog state
  const [loginOpen, setLoginOpen] = useState(false);
  const [cardNumber, setCardNumber] = useState("");
  const [nidNumber, setNidNumber] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const unreadCount = notifications.filter(n => !n.read).length;
  const markAllRead = () => setNotifications(prev => prev.map(n => ({ ...n, read: true })));

  const handleCardInput = (val: string) => {
    const digits = val.replace(/\D/g, "").slice(0, 16);
    const formatted = digits.replace(/(.{4})/g, "$1 ").trim();
    setCardNumber(formatted);
    setError("");
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    const rawCard = cardNumber.replace(/\s/g, "");
    if (rawCard.length < 16 || !nidNumber.trim()) {
      setError("১৬ সংখ্যার কার্ড নম্বর এবং NID নম্বর উভয়ই প্রয়োজন");
      return;
    }
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/krishok-card/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ cardNumber: rawCard, nidNumber: nidNumber.trim() }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        setError(data.error === "Card not found"
          ? "কার্ড নম্বরটি পাওয়া যায়নি"
          : data.error === "NID does not match"
          ? "NID নম্বর সঠিক নয়"
          : "যাচাইকরণ ব্যর্থ হয়েছে। আবার চেষ্টা করুন।");
        return;
      }
      const data = await res.json();
      setUser({
        name: data.farmerNameBn || data.farmerName,
        cardNumber: data.cardNumber,
        nidNumber: data.nidNumber,
        district: data.district,
        upazila: data.upazila,
        status: data.status,
      });
      setLoginOpen(false);
      setCardNumber("");
      setNidNumber("");
    } catch {
      setError("সংযোগ সমস্যা। আবার চেষ্টা করুন।");
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    setUser(null);
    setCardNumber("");
    setNidNumber("");
    setError("");
  };

  return (
    <>
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center mx-auto px-4">

          {/* Logo — desktop */}
          <div className="items-center gap-2 mr-4 hidden md:flex">
            <Link href="/" className="flex items-center gap-2 text-primary font-bold text-xl">
              <Leaf className="h-6 w-6" />
              <span>এগ্রোবাংলা</span>
            </Link>
          </div>

          {/* Mobile hamburger */}
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" className="mr-2 px-0 text-base hover:bg-transparent focus-visible:bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 md:hidden">
                <Menu className="h-6 w-6" />
                <span className="sr-only">Toggle Menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="pr-0">
              <SheetTitle>
                <Link href="/" onClick={() => setOpen(false)} className="flex items-center gap-2 text-primary font-bold text-xl mb-8">
                  <Leaf className="h-6 w-6" />
                  <span>এগ্রোবাংলা</span>
                </Link>
              </SheetTitle>
              <div className="flex flex-col gap-3">
                {links.map((link) => {
                  const Icon = link.icon;
                  return (
                    <Link key={link.href} href={link.href} onClick={() => setOpen(false)}
                      className={`flex items-center gap-2 text-lg ${location === link.href ? "text-primary font-semibold" : "text-muted-foreground"}`}>
                      <Icon className="h-5 w-5" />
                      {link.label}
                    </Link>
                  );
                })}
              </div>
            </SheetContent>
          </Sheet>

          {/* Logo — mobile */}
          <div className="flex items-center gap-2 mr-4 md:hidden">
            <Link href="/" className="flex items-center gap-2 text-primary font-bold text-lg">
              <Leaf className="h-5 w-5" />
              <span>এগ্রোবাংলা</span>
            </Link>
          </div>

          {/* Center nav */}
          <div className="flex-1 flex items-center justify-center hidden md:flex">
            <nav className="flex items-center gap-6 text-sm font-medium">
              {links.slice(1, 6).map((link) => (
                <Link key={link.href} href={link.href}
                  className={`transition-colors hover:text-primary ${location === link.href ? "text-primary" : "text-muted-foreground"}`}>
                  {link.label}
                </Link>
              ))}
            </nav>
          </div>

          {/* Right section */}
          <div className="flex items-center justify-end flex-1 md:flex-none gap-1">

            {/* Extra nav links */}
            <div className="hidden md:flex items-center gap-4 mr-2">
              {links.slice(6).map((link) => (
                <Link key={link.href} href={link.href}
                  className={`text-sm font-medium transition-colors hover:text-primary ${location === link.href ? "text-primary" : "text-muted-foreground"}`}>
                  {link.label}
                </Link>
              ))}
            </div>

            {/* Notification Bell */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="relative">
                  <Bell className="h-5 w-5" />
                  {unreadCount > 0 && (
                    <span className="absolute -top-0.5 -right-0.5 h-4 w-4 rounded-full bg-red-500 text-[10px] font-bold text-white flex items-center justify-center leading-none">
                      {unreadCount}
                    </span>
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-80">
                <div className="flex items-center justify-between px-3 py-2">
                  <DropdownMenuLabel className="p-0 font-semibold text-base">বিজ্ঞপ্তি</DropdownMenuLabel>
                  {unreadCount > 0 && (
                    <button onClick={markAllRead} className="flex items-center gap-1 text-xs text-primary hover:underline">
                      <CheckCheck className="w-3.5 h-3.5" /> সব পড়া হয়েছে
                    </button>
                  )}
                </div>
                <DropdownMenuSeparator />
                <div className="max-h-72 overflow-y-auto">
                  {notifications.map((n) => {
                    const Icon = n.icon;
                    return (
                      <div key={n.id}
                        className={`flex gap-3 px-3 py-2.5 hover:bg-muted/50 cursor-pointer transition-colors ${!n.read ? "bg-primary/5" : ""}`}
                        onClick={() => setNotifications(prev => prev.map(x => x.id === n.id ? { ...x, read: true } : x))}>
                        <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center shrink-0 mt-0.5">
                          <Icon className={`w-4 h-4 ${n.color}`} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-2">
                            <p className="text-sm font-semibold truncate">{n.title}</p>
                            {!n.read && <span className="w-2 h-2 rounded-full bg-primary shrink-0" />}
                          </div>
                          <p className="text-xs text-muted-foreground leading-snug mt-0.5">{n.body}</p>
                          <p className="text-[10px] text-muted-foreground mt-1">{n.time}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
                <DropdownMenuSeparator />
                <div className="px-3 py-2 text-center">
                  <button className="text-xs text-primary hover:underline">সব বিজ্ঞপ্তি দেখুন</button>
                </div>
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Theme toggle */}
            <Button variant="ghost" size="icon" aria-label="Toggle Theme"
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>
              <Sun className="h-5 w-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
              <Moon className="absolute h-5 w-5 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
            </Button>

            {/* Login / Profile */}
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center gap-2 px-2 h-9">
                    <Avatar className="h-7 w-7">
                      <AvatarFallback className="bg-primary text-primary-foreground text-xs font-bold">
                        {user.name.slice(0, 1)}
                      </AvatarFallback>
                    </Avatar>
                    <span className="hidden md:block text-sm font-medium max-w-28 truncate">{user.name}</span>
                    <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-60">
                  <div className="px-3 py-2.5 space-y-0.5">
                    <p className="font-semibold text-sm">{user.name}</p>
                    <p className="text-xs text-muted-foreground font-mono">{user.cardNumber}</p>
                    <p className="text-xs text-muted-foreground">{user.district}{user.upazila ? `, ${user.upazila}` : ""}</p>
                    <span className={`inline-block text-[10px] px-1.5 py-0.5 rounded-full font-medium mt-1 ${
                      user.status === "active" ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
                      : user.status === "pending" ? "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400"
                      : "bg-muted text-muted-foreground"
                    }`}>
                      {user.status === "active" ? "✓ সক্রিয়" : user.status === "pending" ? "⏳ অপেক্ষমান" : user.status}
                    </span>
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/krishok-card" className="flex items-center gap-2 cursor-pointer">
                      <CreditCard className="w-4 h-4" /> কৃষক কার্ড
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="gap-2 cursor-pointer">
                    <Settings className="w-4 h-4" /> সেটিংস
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem className="gap-2 cursor-pointer text-red-600 focus:text-red-600" onClick={handleLogout}>
                    <LogOut className="w-4 h-4" /> লগ আউট
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Button size="sm" className="gap-1.5 font-semibold" onClick={() => { setError(""); setLoginOpen(true); }}>
                <LogIn className="h-4 w-4" />
                <span className="hidden sm:inline">লগইন</span>
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* ── Login Dialog ── */}
      <Dialog open={loginOpen} onOpenChange={(v) => { setLoginOpen(v); if (!v) setError(""); }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-xl">
              <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center">
                <CreditCard className="w-5 h-5 text-primary" />
              </div>
              কৃষক কার্ড দিয়ে লগইন
            </DialogTitle>
            <DialogDescription>
              আপনার নিবন্ধিত কৃষক কার্ড নম্বর এবং NID নম্বর দিয়ে প্রবেশ করুন।
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleLogin} className="space-y-4 mt-2">
            <div className="space-y-1.5">
              <Label htmlFor="cardNumber">কৃষক কার্ড নম্বর</Label>
              <Input
                id="cardNumber"
                placeholder="1234 5678 9012 3456"
                value={cardNumber}
                onChange={e => handleCardInput(e.target.value)}
                disabled={loading}
                autoComplete="off"
                inputMode="numeric"
                maxLength={19}
                className="font-mono tracking-widest text-lg"
              />
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="nidNumber">জাতীয় পরিচয়পত্র (NID) নম্বর</Label>
              <Input
                id="nidNumber"
                placeholder="১৩ বা ১৭ সংখ্যার NID নম্বর"
                value={nidNumber}
                onChange={e => { setNidNumber(e.target.value); setError(""); }}
                disabled={loading}
                autoComplete="off"
                className="font-mono"
              />
            </div>

            {error && (
              <div className="flex items-center gap-2 text-sm text-red-600 bg-red-50 dark:bg-red-950/30 dark:text-red-400 px-3 py-2 rounded-md">
                <AlertCircle className="w-4 h-4 shrink-0" />
                {error}
              </div>
            )}

            <div className="bg-muted/50 rounded-md px-3 py-2 text-xs text-muted-foreground">
              <p className="font-medium mb-0.5">পরীক্ষামূলক তথ্য:</p>
              <p>কার্ড: <span className="font-mono text-foreground">1234 5678 9012 3456</span></p>
              <p>NID: <span className="font-mono text-foreground">1990123456789</span></p>
            </div>

            <div className="flex gap-3 pt-1">
              <Button type="button" variant="outline" className="flex-1" onClick={() => setLoginOpen(false)} disabled={loading}>
                বাতিল
              </Button>
              <Button type="submit" className="flex-1 gap-2" disabled={loading}>
                {loading ? <><Loader2 className="w-4 h-4 animate-spin" /> যাচাই হচ্ছে...</> : <><LogIn className="w-4 h-4" /> লগইন</>}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}
